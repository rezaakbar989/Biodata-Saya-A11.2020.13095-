package com.example.biodata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void cellphone(View view) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:085643100383"));
        startActivity(intent);
    }

    public void alamat(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("geo:-7.072444414991167, 110.3912777192676"));
        startActivity(intent);
    }

    public void email(View view) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"ra.rezaakbar@gmail.com"});
        intent.putExtra(Intent.EXTRA_SUBJECT, "Dia hanya bercanda!");

        try {
            startActivity(Intent.createChooser(intent, "Harusnya aku tertawa, bukan malah jatuh cinta :)"));
        } catch (android.content.ActivityNotFoundException ex) {
        }
    }
}